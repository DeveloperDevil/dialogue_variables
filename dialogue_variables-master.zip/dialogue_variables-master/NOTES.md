AIRPORT TRANSFER
https://cars.cartrawler.com/norwegian-new/${HOTEL_CAR_LANGUAGE_CODE?trim}/gt/?clientID=${CAR_CLIENT_ID?trim}&Currency=${CURRENCY?trim}&pickupIATACode=${DESTINATION_IATA?trim}&pickupDateTime=${DEPARTURE_YEAR?trim}-${DEPARTURE_MONTH?trim}-${DEPARTURE_DAY?trim}T09:00&returnDateTime=${RETURN_YEAR?trim}-${RETURN_MONTH?trim}-${RETURN_DAY?trim}T09:00&oneway=${ONEWAY_YN?trim}



needs to be like this
https://cars.cartrawler.com/norwegian-new/es/gt/?clientID=846670&Currency=EUR&pickupIATACode=EWR&pickupDateTime=2018-04-10&returnDateTime=2018-04-11&oneway=1#/search 









CAR RENTAL ARTICLE
https://cars.cartrawler.com/norwegian-new/${HOTEL_CAR_LANGUAGE_CODE?trim}/book?clientID=${CAR_CLIENT_ID?trim}&residencyId=${AIRPORT_LANG?lower_case?trim}&currency=${CURRENCY?trim}&lang=${HOTEL_CAR_LANGUAGE_CODE?trim}&pickupIATACode=${DESTINATION_IATA?trim}&returnIATACode=${DESTINATION_IATA?trim}&pickupDateTime=${DEPARTURE_YEAR?trim}-${DEPARTURE_MONTH?trim}-${DEPARTURE_DAY?trim}T09:00&returnDateTime=${RETURN_YEAR?trim}-${RETURN_MONTH?trim}-${RETURN_DAY?trim}T09:00&oneway=${ONEWAY_YN?trim}

OLD LINK AIRPORT TRANSFER

https://www.norwegian.com/${MARKET?trim}/${DESTINATION_URL_PART?trim}
