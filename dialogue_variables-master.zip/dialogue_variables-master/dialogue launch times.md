MAX LONGHAUL launched in UK market only 26/07/18

| Dialogue name  | Time sent out | Notes|
| ---- | ----| ----|
| E_MAX_LH_12DB | 2.30pm | ----|
|E_MAX_LH_12DB_CHASER | 2.30pm | ----|
|E_MAX_LH_1DA | 2.30pm | ----|
|E_MAX_LH_1DB | 2.30pm | ----|
|E_MAX_LH_23DB | 2.30pm| ----|
|E_MAX_LH_2DA | 2.30pm| ----|
|E_MAX_LH_4DB | 2.30pm| ----|
|E_MAX_LH_5DA | 2.30pm| ----|
|E_MAX_LH_7DB | 2.30pm| ----|
|E_MAX_LH_7DB_CHASER | 2.30pm| ----|
|E_MAX_LH_9DB | 2.30pm | ----|
|E_MAX_LH_RET_HOME | 2.30pm | ----|



LONGHAUL PROGRAM

| Dialogue name  | Time sent out | Notes|
| ---- | ----| ----|
| E_LHP_1DA  | 1:30 PM  | ----|
| E_LHP_2DA  | 1:30 PM  | ----|
| E_LHP_5DA  | 1:30 PM  | ----|
| E_LHP_1DB  | 1:00 PM  | ----|
| E_LHP_4DB  | 1:00 PM  | has premium column for previewing! |
| E_LHP_7DB  | 1:00 PM  | ----|
| E_LHP_9DB  | 1:00 PM  | ----|
| E_LHP_12DB  | 1:00 PM  | ----|
| E_LHP_12DB_CHASER  | 1:30 PM  | ----|
| E_LHP_23DB | 1:30 PM  | ----|
| E_LHP_23DB_CHASER  | 1:30 PM  | ----|
| E_LHP_RET_HOME  | 1:30 PM  | ----|
| E_LHP_NEWTRIP_ROUND  | 1:30 PM  | this campaign works like welcome home |
| E_LHP_NEWTRIP_ONEWAY  | 1:30 PM | this campaign works like welcome home |

SHORTHAUL PROGRAM

| Dialogue name  | Time sent out | Notes|
| ---- | ---- |----|
| E_SH_2DA  | 1:20 PM  |----|
| E_SH_1DB | 1:30 PM |----|
| E_SH_3DB  | 1:30 PM |----|
| E_SH_3DB_CHASER | 1:30 PM |----|
| E_SH_6DB  | 1:30 PM |----|
| E_SH_RET_HOME | 1:30 PM |----|
| E_SH_WHOME  | 1:30 PM |----|
